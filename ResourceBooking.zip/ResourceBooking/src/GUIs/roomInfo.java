package GUIs;

import java.awt.Color;

public class roomInfo extends javax.swing.JFrame {

    private static String room1 = "Small room, can fit 2 people for 1 to 1 interviews";
    private static String room2 = "Small room, can fit up to 4 people for smaller meetings";
    private static String room3 = "Medium room, can fit up to 8 people for team meetings";
    private static String room4 = "Medium room, can fit 15 people, this is the only room with disabled access";
    private static String room5 = "Large room, can fit 50 people for large department meetings";
    
    public roomInfo() {
        initComponents();
        room1Button.setBackground(Color.WHITE);
        room2Button.setBackground(Color.WHITE);
        room3Button.setBackground(Color.WHITE);
        room4Button.setBackground(Color.WHITE);
        room5Button.setBackground(Color.WHITE);
        backButton.setBackground(Color.WHITE);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        room1Button = new javax.swing.JButton();
        room2Button = new javax.swing.JButton();
        room3Button = new javax.swing.JButton();
        room4Button = new javax.swing.JButton();
        room5Button = new javax.swing.JButton();
        roomTitle = new javax.swing.JLabel();
        roomDisplay = new javax.swing.JLabel();
        backButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setText("Room Information");

        room1Button.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        room1Button.setText("Room 1:");
        room1Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                room1ButtonActionPerformed(evt);
            }
        });

        room2Button.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        room2Button.setText("Room 2:");
        room2Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                room2ButtonActionPerformed(evt);
            }
        });

        room3Button.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        room3Button.setText("Room 3:");
        room3Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                room3ButtonActionPerformed(evt);
            }
        });

        room4Button.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        room4Button.setText("Room 4:");
        room4Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                room4ButtonActionPerformed(evt);
            }
        });

        room5Button.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        room5Button.setText("Room 5:");
        room5Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                room5ButtonActionPerformed(evt);
            }
        });

        roomTitle.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N

        roomDisplay.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N

        backButton.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        backButton.setText("Back");
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(room1Button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 173, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addComponent(room2Button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(room3Button, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(room4Button, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(roomTitle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(roomDisplay, javax.swing.GroupLayout.DEFAULT_SIZE, 415, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(109, 109, 109)
                        .addComponent(room5Button, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(31, 31, 31))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(room1Button, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(room2Button, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(roomTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(room3Button, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(room4Button, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(roomDisplay, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(room5Button, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void room1ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_room1ButtonActionPerformed
        roomTitle.setText("Room 1:");
        roomDisplay.setText(room1);
    }//GEN-LAST:event_room1ButtonActionPerformed

    private void room2ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_room2ButtonActionPerformed
        roomTitle.setText("Room 2:");
        roomDisplay.setText(room2);
    }//GEN-LAST:event_room2ButtonActionPerformed

    private void room3ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_room3ButtonActionPerformed
        roomTitle.setText("Room 3:");
        roomDisplay.setText(room3);
    }//GEN-LAST:event_room3ButtonActionPerformed

    private void room4ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_room4ButtonActionPerformed
        roomTitle.setText("Room 4:");
        roomDisplay.setText(room4);
    }//GEN-LAST:event_room4ButtonActionPerformed

    private void room5ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_room5ButtonActionPerformed
        roomTitle.setText("Room 5:");
        roomDisplay.setText(room5);
    }//GEN-LAST:event_room5ButtonActionPerformed

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        roomBooking roomBooking = new roomBooking();
        roomBooking.setVisible(true);
        roomBooking.setResizable(false);
        this.dispose();
    }//GEN-LAST:event_backButtonActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(roomInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(roomInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(roomInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(roomInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new roomInfo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JButton room1Button;
    private javax.swing.JButton room2Button;
    private javax.swing.JButton room3Button;
    private javax.swing.JButton room4Button;
    private javax.swing.JButton room5Button;
    private javax.swing.JLabel roomDisplay;
    private javax.swing.JLabel roomTitle;
    // End of variables declaration//GEN-END:variables
}
