package GUIs;



public class ResourceBooking {

    public static void main(String[] args) {
        LoginPage login = new LoginPage();
        login.setVisible(true);
        login.setResizable(false);
    }
    
}
