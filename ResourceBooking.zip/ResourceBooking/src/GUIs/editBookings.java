package GUIs;

import Objects.Booking;
import Objects.fileRead;
import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class editBookings extends javax.swing.JFrame {

    private static ArrayList<Booking> bookingsList = fileRead.bookingsList;
    private static ArrayList<String> bookingEmails = fileRead.bookingEmails;
    public static ArrayList<Booking> myBookings = new ArrayList<>();

    private static ArrayList<Integer> bookingNums = new ArrayList<>();

    private static String checkEmail;
    private static Booking tempBooking;
    private static String myEmail = LoginPage.email;

    private static int rowEdit;
    private static Booking editBooking;

    private static int tempNum;
    private static int removeNum;

    public editBookings() {
        initComponents();
        menuButton.setBackground(Color.WHITE);
        
        bookingsDisplay.setVisible(true);
        bookingsDisplay.setEnabled(false);
        bookingsDisplay.setCellSelectionEnabled(true);
        currentBookings();
    }

    public static void currentBookings() {

        for (int i = 0; i < bookingsList.size(); i++) {
            bookingsList.remove(i);
            bookingEmails.remove(i);
        }

        for (int i = 0; i < bookingsList.size(); i++) {
            checkEmail = bookingEmails.get(i);
            if (checkEmail.equals(myEmail)) {
                tempBooking = bookingsList.get(i);
                myBookings.add(tempBooking);
                tempNum = i;
                bookingNums.add(tempNum);
            }
        }

        bookingTable();
    }

    public static void bookingTable() {

        try {
            String[] columns = {"Email Address", "Day Of The Week", "Date Of Booking", "Room Number", "Start Time", "Duration", "Cancelled Status"};
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            Object[][] rows = new Object[myBookings.size()][columns.length];

            for (int x = 0; x < myBookings.size(); x++) {

                rows[x][0] = myBookings.get(x).getEmail();
                rows[x][1] = myBookings.get(x).getDay().toUpperCase();
                rows[x][2] = dateFormat.format(myBookings.get(x).getBookingDate());
                rows[x][3] = myBookings.get(x).getroomNum();
                rows[x][4] = myBookings.get(x).getStartTime();
                rows[x][5] = myBookings.get(x).getDuration();
                rows[x][6] = myBookings.get(x).getActive();
            }

            bookingsDisplay.setModel(new javax.swing.table.DefaultTableModel(rows, columns));

        } catch (Exception e) {
//            System.out.println("ERROR: " + e);
        }

    }

    public static void activeStatus() {

        try {
            if (editBooking.Active == true) {
                editBooking.Active = false;
            } else {
                editBooking.Active = true;
            }

            removeNum = bookingNums.get(rowEdit);
            fileRead.bookingsList.remove(removeNum);
            fileRead.bookingsList.add(removeNum, editBooking);

            currentBookings();
        } catch (Exception e) {
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        bookingsDisplay = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        menuButton = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        activeInput = new javax.swing.JTextField();
        confirmButton = new javax.swing.JButton();

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setText("Current Bookings");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jScrollPane1.setViewportView(bookingsDisplay);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel2.setText("My Bookings");

        menuButton.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        menuButton.setText("Main Menu");
        menuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuButtonActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel3.setText("Please enter row of the booking you would like to change:");

        confirmButton.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        confirmButton.setText("Confirm");
        confirmButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(menuButton, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(activeInput, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(confirmButton)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(267, 267, 267))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(menuButton, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(activeInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(confirmButton))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void menuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuButtonActionPerformed
        MainMenu menu = new MainMenu();
        menu.setVisible(true);
        menu.setResizable(false);
        this.dispose();
    }//GEN-LAST:event_menuButtonActionPerformed

    private void confirmButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmButtonActionPerformed
        if (activeInput.getText() != null) {
            rowEdit = Integer.parseInt(activeInput.getText());
            editBooking = myBookings.get(rowEdit);
            activeStatus();
        } else {
            JOptionPane.showMessageDialog(this, "Error editing booking, Please try again");
        }
    }//GEN-LAST:event_confirmButtonActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(editBookings.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(editBookings.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(editBookings.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(editBookings.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new editBookings().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField activeInput;
    private static javax.swing.JTable bookingsDisplay;
    private javax.swing.JButton confirmButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton menuButton;
    // End of variables declaration//GEN-END:variables
}
