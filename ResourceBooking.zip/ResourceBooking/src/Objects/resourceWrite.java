package Objects;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class resourceWrite {
    
    public static String fileName = "Resource.txt";
    
    public static void fileWriter() {

        try {
            FileOutputStream fileOut = new FileOutputStream(fileName, true);
            ObjectOutputStream objOut = new ObjectOutputStream(fileOut);
            objOut.writeObject(GUIs.resources.newOrder);
            System.out.println("Order: " + GUIs.resources.newOrder.Email + " " + GUIs.resources.newOrder.startTime + " " + GUIs.resources.newOrder.roomNum + " " + GUIs.resources.newOrder.projector + " " + GUIs.resources.newOrder.laptop + " " + GUIs.resources.newOrder.pens + " " + GUIs.resources.newOrder.paper);
            objOut.close();
        } catch (Exception e) {
//            System.out.println("ERROR: " + e);
        }
        
        resourceRead.fileReader();
    }
}
