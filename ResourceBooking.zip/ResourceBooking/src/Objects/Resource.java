package Objects;

import java.io.Serializable;

public class Resource implements Serializable {
    
    public String Email;
    public String startTime;
    public int roomNum;
    public boolean projector;
    public boolean laptop;
    public int pens;
    public int paper;
    
    public Resource (String Email, String startTime, int roomNum, boolean projector, boolean laptop, int pens, int paper) {
        this.Email = Email;
        this.startTime = startTime;
        this.roomNum = roomNum;
        this.projector = projector;
        this.laptop = laptop;
        this.pens = pens;
        this.paper = paper;
    }
    
    public String printResource() {
        return "Registered email address: " + Email + ", Time of booking: " + startTime +  ", Room number: " + roomNum + ", Projector requested: " + projector + ", Laptop requested: " + laptop + ", Pens needed: " + pens + ", Paper needed: " + paper;
    }
    
    public String getEmail() {
        return Email;
    }
    
    public void setEmail(String Email) {
        this.Email = Email;
    }
    
    public String getStartTime() {
        return startTime;
    }
    
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }
    
    public int getRoomNum() {
        return roomNum;
    }
    
    public void setRoomNum(int roomNum) {
        this.roomNum = roomNum;
    }
    
    public boolean getProjector() {
        return projector;
    }
    
    public void setProjector(boolean projector) {
        this.projector = projector;
    }
    
    public boolean getLaptop() {
        return laptop;
    }
    
    public void setLaptop(boolean laptop) {
        this.laptop = laptop;
    }
    
    public int getPens() {
        return pens;
    }
    
    public void setPens(int pens) {
        this.pens = pens;
    }
    
    public int getPaper() {
        return paper;
    }
    
    public void setPaper(int paper) {
        this.paper = paper;
    }
}
