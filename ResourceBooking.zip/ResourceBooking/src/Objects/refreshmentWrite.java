package Objects;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class refreshmentWrite {
    
    public static String fileName = "Refreshment.txt";
    
    public static void fileWriter() {

        try {
            FileOutputStream fileOut = new FileOutputStream(fileName, true);
            ObjectOutputStream objOut = new ObjectOutputStream(fileOut);
            objOut.writeObject(GUIs.refreshments.newOrder);
            System.out.println("Order: " + GUIs.refreshments.newOrder.Email + " " + GUIs.refreshments.newOrder.startTime + " " + GUIs.refreshments.newOrder.roomNum + " " + GUIs.refreshments.newOrder.pastries + " " + GUIs.refreshments.newOrder.sandwiches + " " + GUIs.refreshments.newOrder.water + " " + GUIs.refreshments.newOrder.coffee + " " + GUIs.refreshments.newOrder.tea);
            objOut.close();
        } catch (Exception e) {
            System.out.println("ERROR: " + e);
        }
        
        refreshmentRead.fileReader();
    }
}
