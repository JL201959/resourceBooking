package Objects;

import java.sql.Date;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class alreadyBooked {

    private static ArrayList<Booking> bookingsList = fileRead.bookingsList;
    private static ArrayList<Date> bookingsDates = fileRead.bookingDates;
    private static ArrayList<Integer> bookingTimes = fileRead.bookingTimes;
    private static ArrayList<Integer> bookingDuration = fileRead.bookingDuration;
    private static ArrayList<Integer> bookingRooms = fileRead.bookingRooms;

    private static Date listDate;
    private static Date checkDate = GUIs.roomBooking.tempBooking.BookingDate;

    private static int listStartTime;
    private static int listEndTime;

    private static int listRoomNum;
    private static int checkRoomNum = GUIs.roomBooking.tempBooking.roomNum;

    private static String firstDigits = GUIs.roomBooking.tempBooking.StartTime.substring(0, 2);
    private static int checkStartTime = Integer.parseInt(firstDigits);
    private static int checkEndTime = checkStartTime + GUIs.roomBooking.tempBooking.Duration;

    public static boolean canBook = true;

    public static void bookingCheck() {

        try {
            for (int i = 0; i < bookingsDates.size(); i++) {
                listDate = bookingsDates.get(i);
                if (listDate.equals(checkDate)) {
                    listStartTime = bookingTimes.get(i);
                    listEndTime = listStartTime + bookingDuration.get(i);

                    if (checkStartTime >= listStartTime && checkStartTime <= listEndTime) {
                        listRoomNum = bookingRooms.get(i);
                        if (listRoomNum == checkRoomNum) {
                            canBook = false;
                            JOptionPane.showMessageDialog(null, "This Meeting Room Is Already Booked, Please View Current Meetings");
                            break;
                        }
                    }
                    if (checkEndTime >= listStartTime && checkEndTime <= listEndTime) {
                        listRoomNum = bookingRooms.get(i);
                        if (listRoomNum == checkRoomNum) {
                            canBook = false;
                            JOptionPane.showMessageDialog(null, "This Meeting Room Is Already Booked, Please View Current Meetings");
                            break;
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("ERROR: " + e);
        }

    }
}
