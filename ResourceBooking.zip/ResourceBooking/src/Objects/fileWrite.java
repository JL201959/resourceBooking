package Objects;

import GUIs.ViewBookings;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class fileWrite {

    public static String fileName = "Bookings.txt";

    public static void fileWriter() {

        try {
            FileOutputStream fileOut = new FileOutputStream(fileName, true);
            ObjectOutputStream objOut = new ObjectOutputStream(fileOut);
            objOut.writeObject(GUIs.roomBooking.newBooking);
            System.out.println("Booking: " + GUIs.roomBooking.newBooking.Email + " " + GUIs.roomBooking.newBooking.Day + " " + GUIs.roomBooking.newBooking.BookingDate + " " + GUIs.roomBooking.newBooking.roomNum + " " + GUIs.roomBooking.newBooking.StartTime + " " + GUIs.roomBooking.newBooking.Duration + " " + GUIs.roomBooking.newBooking.Active);
            objOut.close();
        } catch (Exception e) {
//            System.out.println("ERROR: " + e);
        }
        
        fileRead.fileReader();
    }
}
