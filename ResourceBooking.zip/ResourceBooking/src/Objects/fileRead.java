package Objects;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class fileRead {

    public static ArrayList<Booking> bookingsList = new ArrayList<>();
    public static ArrayList<String> bookingEmails = new ArrayList<>();
    public static ArrayList<Date> bookingDates = new ArrayList<>();
    public static ArrayList<Integer> bookingRooms = new ArrayList<>();
    public static ArrayList<Integer> bookingTimes = new ArrayList<>();
    public static ArrayList<Integer> bookingDuration = new ArrayList<>();

    public static Booking newBooking;
    public static ObjectInputStream objIn;

    public static void fileReader() {
        try {

            for (int i = 0; i < bookingsList.size(); i++) {
                bookingsList.remove(i);
            }

            String fileName = fileWrite.fileName;
            FileInputStream fileIn = new FileInputStream(fileName);

            boolean nullObj = false;

            while (nullObj == false) {
                try {
                    objIn = new ObjectInputStream(fileIn);
                    newBooking = (Booking) objIn.readObject();
                    if (newBooking != null) {
                        
                        bookingsList.add(newBooking);
                        bookingEmails.add(newBooking.Email);
                        bookingDates.add(newBooking.BookingDate);
                        bookingRooms.add(newBooking.roomNum);
                        
                        String firstDigits = newBooking.StartTime.substring(0,2);
                        
                        bookingTimes.add(Integer.parseInt(firstDigits));
                        bookingDuration.add(newBooking.Duration);
                    } else {
                        nullObj = true;
                    }
                } catch (Exception e) {
//                    System.out.println("ERROR: " + e);
                    break;
                }

            }
            objIn.close();

        } catch (Exception e) {
//            System.out.println("ERROR: " + e);
        }
    }
}
