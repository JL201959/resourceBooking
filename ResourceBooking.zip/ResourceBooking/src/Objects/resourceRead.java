package Objects;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class resourceRead {

    public static ArrayList<Resource> orderList = new ArrayList<>();
    
    public static Resource newOrder;
    public static ObjectInputStream objIn;
    
    public static void fileReader() {
        
        try {

            for (int i = 0; i < orderList.size(); i++) {
                orderList.remove(i);
            }

            String fileName = resourceWrite.fileName;
            FileInputStream fileIn = new FileInputStream(fileName);

            boolean nullObj = false;

            while (nullObj == false) {
                try {
                    objIn = new ObjectInputStream(fileIn);
                    newOrder = (Resource) objIn.readObject();
                    if (newOrder != null) {

                        orderList.add(newOrder);
                        
                    } else {
                        nullObj = true;
                    }
                } catch (Exception e) {
//                    System.out.println("ERROR: " + e);
                    break;
                }

            }
            objIn.close();

        } catch (Exception e) {
//            System.out.println("ERROR: " + e);
        }
    }
}
