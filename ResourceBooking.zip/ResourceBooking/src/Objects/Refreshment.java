package Objects;

import java.io.Serializable;

public class Refreshment implements Serializable {

    public String Email;
    public String startTime;
    public int roomNum;
    public int pastries;
    public int sandwiches;
    public int water;
    public int coffee;
    public int tea;

    public Refreshment(String Email, String startTime, int roomNum, int pastries, int sandwiches, int water, int coffee, int tea) {
        this.Email = Email;
        this.startTime = startTime;
        this.roomNum = roomNum;
        this.pastries = pastries;
        this.sandwiches = sandwiches;
        this.water = water;
        this.coffee = coffee;
        this.tea = tea;
    }

    public String printRefreshment() {
        return "Registered email address: " + Email + ", Time of booking: " + startTime + ", Room number: " + roomNum + ", Pastries: " + pastries + ", Sandwiches: " + sandwiches + ", Waters: " + water + ", Coffees: " + coffee + ", Teas: " + tea;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public int getRoomNum() {
        return roomNum;
    }

    public void setRoomNum(int roomNum) {
        this.roomNum = roomNum;
    }
    
    public int getPastries() {
        return pastries;
    }
    
    public void setPastries(int pastries) {
        this.pastries = pastries;
    }
    
    public int getSandwiches() {
        return sandwiches;
    }
    
    public void setSandwiches(int sandwiches) {
        this.sandwiches = sandwiches;
    }
    
    public int getWater() {
        return water;
    }
    
    public void setWater(int water) {
        this.water = water;
    }
    
    public int getCoffee() {
        return coffee;
    }
    
    public void setCoffee(int coffee) {
        this.coffee = coffee;
    }
    
    public int getTea() {
        return tea;
    }
    
    public void setTea(int tea) {
        this.tea = tea;
    }
}
