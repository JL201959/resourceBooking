package Objects;

import java.sql.Date;
import java.io.Serializable;

public class Booking implements Serializable {
    
    public String Email;
    public String Day;
    public Date BookingDate;
    public int roomNum;
    public String StartTime;
    public int Duration;
    public boolean Active;
    
    public Booking (String Email, String Day, Date BookingDate, int roomNum, String StartTime, int Duration, boolean Active){
        this.Email = Email;
        this.Day = Day;
        this.BookingDate = BookingDate;
        this.roomNum = roomNum;
        this.StartTime = StartTime;
        this.Duration = Duration;
        this.Active = Active; 
    }
    
    public String printBooking() {
        return "Registered email address: " + Email + ", Day of booking: " + Day + ", Date of booking: " + BookingDate + ", Room number: " + roomNum + ", Time of booking: " + StartTime + ", Duration of booking: " + Duration + " hours ,Booking status: " + Active;
    }
    
    public String getEmail() {
        return Email;
    }
    
    public void setEmail(String Email) {
        this.Email = Email;
    }
    
    public String getDay() {
        return Day;
    }
    
    public void setDay(String Day) {
        this.Day = Day;
    }
    
    public Date getBookingDate() {
        return BookingDate;
    }
    
    public void setBookingDate(Date BookingDate) {
        this.BookingDate = BookingDate;
    }
    
    public int getroomNum() {
        return roomNum;
    }
    
    public void setroomNum(int roomNum) {
        this.roomNum = roomNum;
    }
    
    public String getStartTime() {
        return StartTime;
    }
    
    public void setStartTime(String StartTime) {
        this.StartTime = StartTime;
    }
    
    public int getDuration() {
        return Duration;
    }
    
    public void setDuration(int Duration) {
        this.Duration = Duration;
    }
    
    public boolean getActive() {
        return Active;
    }
    
    public void setActive(boolean Active) {
        this.Active = Active;
    }
}
